var handleGUI = function() {
        var head = '';
        head += '<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">';
        head += '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">';
        head += '<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">';
        $('head').prepend(head);
        var body = '';
        body += '<div class="bootstrap inspinia fb-tool-element" >';
        body += '<div class="fb-tool-header">';
        body += '<h1 class="header-title">SRT Tool</h1>';
        body += '<i class="fas fa-times app-exit"></i>';
        body += '</div>';
        body += '<div class="fb-tool-content">';
        body += '<div class="h-navigator">';
        body += '<ul class="list-unstyled">';
        body += '<li>';
        body += '<a href="#">Components</a>';
        body += '</li>';
        body += '<li>';
        body += '<a href="#">Jeonsoft</a>';
        body += '</li>';
        body += '<li>';
        body += '<a href="#">Kronos</a>';
        body += '</li>';
        body += '<li>';
        body += '<a href="#">Theme</a>';
        body += '</li>';
        body += '</ul>';
        body += '</div>';
        body += '<div class="h-t-content mt-2">';
        body += '<div class="dev-mode closed">';
        body += '<div class="dev-header">';
        body += '<a href="#" class="trigger"><i class="fas fa-code"></i></a>';
        body += '<h3>Console Window</h3>';
        body += '<hr>';
        body += '</div>';
        body += '<div class="dev-body">';
        body += '</div>';
        body += '</div>';
        body += '<div class="status-c">';
        body += '<h1>Auto Dump & Exit</h1>';
        body += '<span class="component-status"><strong>Status: </strong> Active </span>';
        body += '</div>';
        body += '<div class="row">';
        body += '<div class="col-md-12">';
        body += '<label class="comp-title">Component URL</label>';
        body += '<input type="text" class="form-control c-url-input" placeholder="Waiting for Component URL" value="" autocomplete="off" readonly>';
        body += '</div>';
        body += '</div>';
        body += '<div class="row mt-3">';
        body += '<div class="col-md-6">';
        body += '<label class="comp-title">Element ID</label>';
        body += '<input type="text" class="form-control c-el-id" placeholder="Waiting for Element ID" autocomplete="off" readonly>';
        body += '</div>';
        body += '<div class="col-md-6">';
        body += '<label class="comp-title">Dump ID</label>';
        body += '<input type="text" class="form-control d-id" placeholder="Waiting for Dump ID" autocomplete="off" readonly>';
        body += '</div>';
        body += '</div>';
        body += '</div>';
        body += '<div class="tagging-tree-c mt-5">';
        body += '<div class="status-c">';
        body += '<h1>Tagging Tree</h1>';
        body += '<span class="tagging-tree-status"><strong>Status: </strong> Active </span>';
        body += '</div>';
        body += '<div class="pattern-c">';
        body += '<div class="pat-controls mt-2">';
        body += '<button type="button" class="btn btn-default safe-mode">Safe</button>';
        body += '<button type="button" class="btn btn-default advanced-mode">Advanced</button>';
        body += '</div>';
        body += '</div>';
        body += '</div>';
        body += '<div class="next-job-c mt-5">';
        body += '<div class="status-c">';
        body += '<h1>Skip Interval</h1>';
        body += '<span class="skip-status"><strong>Status: </strong> Active </span>';
        body += '</div>';
        body += '</div>';
	body += '<div class="idletime-c mt-5">';
        body += '<div class="status-c">';
        body += '<h1>Idle Timer</h1>';
        body += '<span class="skip-status"><strong>Status: </strong> Active </span>';
        body += '</div>';
	body += '<div class="idletime-controls">';
	body += '<button type="button" class="btn btn-default btn-idletime">Idle Time Off</button>';
	body += '</div>';
        body += '</div>';
        body += '</div>';
        body += '</div>';
        $('body').prepend(body);
    },
    handleShowUI = function() {

        $(document).on('keydown', function(e) {
            if (e.which == 45) {

                console.log('Facebook Tool Active');
                $('.fb-tool-element').slideToggle('fast');	
	
            }
	    $('._962 ._2f4f').remove();
        });
        $(document).on('click', '.app-exit', function() {
            $('.fb-tool-element').slideToggle('fast')
        });
	
    },
    handleAutoDump = function() {
        var auto_dump = !0;
        var component_url = $('.c-url-input');
        var c_el_id = $('.c-el-id');
        var d_id = $('.d-id');
        var dump_id = '._271k._271l._271m._1qjd._3-99';
        d_id.val(dump_id);
        if (component_url.val() == '') {
            conError('Component URL not found')
        } else {
            conSuccess('Component URL found')
        }
        $(document).on('click', '._4-u2._57mb._1u44._3-94._4-u8 ._42ft._4jy0._4jy3._517h._51sy', function() {
            var ids = $(this).attr('id');
            var hashID = '#' + ids;
            var shashID = localStorage.setItem('btnJGStrg', hashID);
            
            conSuccess('Component ID Found ' + hashID);
	    // Debug Just Go Button
            //alert(hashID);
       	    
	    localStorage.setItem('JGEStrg', hashID);
	    var urlStrg = $(localStorage.getItem('btnJGStrg')).attr('href');
	    localStorage.setItem('urlStrg', urlStrg);
	    
        });
        
        if (localStorage.getItem('btnJGStrg')) {
            var url = 'https://review.intern.facebook.com' + $(localStorage.getItem('btnJGStrg')).attr('href');	    
        } else {
            conError("ID doesn't exist! (Auto Dump)")
        }
	
        if (localStorage.getItem('dumpStrg') == 'active') {
		if(url != 'https://review.intern.facebook.comundefined'){
			setTimeout(function() {
                		window.location.href = url;
				conSuccess(url);
                		localStorage.setItem('dumpStrg', '');
		
            		}, 3000);
		}
		else {
			setTimeout(function() {
                		conError('Undefined URL '+url);
            		}, 3000);
			
		}
		
        }
	else {
		conError('URL is Undefined. Element ID changed.');
	}
        $(document).on('keydown', function(e) {
            //console.log(e.which);
            if (e.which == 111) {
                if (auto_dump) {
                    var dump = 'active';
                    localStorage.setItem('dumpStrg', dump);
                    setTimeout(function() {
                        $('._271k._271l._271m._1qjd._3-99').click();
                        conSuccess("Auto Dump Success!");
                    }, 1000)
                } else {
                    conError("Auto Dump has been turn off");
                }
            }
        })
    },
    handleNextJobInterval = function() {
        var nextId;
        $('._962 button._4jy0._4jy4._517h._51sy._42ft').hover(function() {
            var btnNextT = $(this).attr('data-tooltip-content');
             
            if (btnNextT == 'Next') {
                nextId = '#' + $(this).attr('id');
                conSuccess('Next Button ID found');
            }
        });
        $(document).on('keydown', function(e) {
            if (e.which == 106) {
                setTimeout(function() {
                    $(nextId).click();
                    conSuccess('Button Next Clicked');
                }, 3000)
            }
        });
    },
    handleAutoTaggingTree = function() {
        var pattern_1;
        var pattern_2;
        var pattern_status;
        $('.safe-mode').on('click', function() {
            pattern_status = false;
	    conSuccess('Safe Mode');
        });
        $('.advanced-mode').on('click', function() {
            pattern_status = true;
	    conSuccess('Advanced Mode');
        });
        $(document).on('keydown', function(e) {
            if (e.which == 109) {
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 500);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                    console.log('Submit')
                }, 700);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 900);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                    console.log('Submit')
                }, 1100);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 1300);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                    console.log('Submit')
                }, 1500);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 1700);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                    console.log('Submit')
                }, 1900);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 2100);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                    console.log('Submit')
                }, 2300);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 2500);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                    console.log('Submit')
                }, 2700);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 2900);
                if (pattern_status == false) {
                    setTimeout(function() {
                        $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                        console.log('Submit')
                    }, 3100)
                }
            }
            if (e.which == 107) {
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 500);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                    console.log('Submit')
                }, 700);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 900);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                    console.log('Submit')
                }, 1100);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sh input').last().click();
                    console.log('No')
                }, 1300);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 1500);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                    console.log('Submit')
                }, 1700);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 1900);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                    console.log('Submit')
                }, 2100);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 2300);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                    console.log('Submit')
                }, 2500);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 2700);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                    console.log('Submit')
                }, 2900);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 3100);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                    console.log('Submit')
                }, 3300);
                setTimeout(function() {
                    $('._6ugs._4-u2._4-u8 ._55sg._kv1 input').last().click();
                    console.log('No')
                }, 3500);
                if (pattern_status) {
                    setTimeout(function() {
                        $('._6ugs._4-u2._4-u8 ._4jy0._4jy3._4jy1._51sy.selected._42ft').click();
                        console.log('Submit')
                    }, 3700)
                }
            }
        })
    },
    handleConsoleWindow = function() {
        var dev_active = 0;
        $('.trigger').on('click', function() {
            if (dev_active == 0) {
                showConsole();
		localStorage.setItem('consoleWindowMode', 'show');
            } else if (dev_active == 1) {
		hideConsole();
		localStorage.setItem('consoleWindowMode', 'hide');
            }
        });
	if(localStorage.getItem('consoleWindowMode') == 'show'){
		showConsole();
	}
	else {
		hideConsole();
	}
	function showConsole(){
		$('.trigger i').addClass('fa-times').removeClass('fa-code');
                $('.dev-mode').animate({
                    width: '100%'
                }).removeClass('closed').addClass('opened');
                $('.dev-mode .dev-body, .dev-mode .dev-header h3').css('display', 'block');
                dev_active = 1;
	}
	function hideConsole(){
		$('.trigger i').addClass('fa-code').removeClass('fa-times');
                $('.dev-mode').animate({
                    width: '0'
                }).removeClass('opened').addClass('closed');
                $('.dev-mode .dev-body, .dev-mode .dev-header h3').css('display', 'none');
                dev_active = 0;
	}
    },
handleSRTIdle = function(){

var idletimemode = 0;
var min = 0;
var sec = 0;
var idleTime; 

$(document).on('click', '._4-u2._57mb._1u44._3-94._4-u8 ._42ft._4jy0._4jy3._517h._51sy', function() {

	localStorage.setItem('is_onTheJob', 'yes');
});

$(document).on('click', '._271k._271l._271m._1qjd._3-99', function(){	

	localStorage.setItem('is_onTheJob', 'no');
});

var timeout = null;
var timeIni = null;
var iotjTimeout = null;
var notjTimeout = null;
var autoReloadTimer = null;

var idle = 3;
var idlet = (idle * 60) * 1000;
var idleExe = 30000;
//var idlet = 10000;


var idleCounts = localStorage.getItem('idleCounts');

localStorage.setItem('is_MouseMove', 'no');
//conSuccess(localStorage.getItem('is_MouseMove'));

$(document).on('mousemove', function() {
	
	$('.c-idle').remove();
    	localStorage.setItem('is_MouseMove', 'yes');

	clearTimeout(timeout);
	clearTimeout(timeIni);
	clearTimeout(iotjTimeout);
	clearTimeout(notjTimeout);
	clearTimeout(autoReloadTimer);

    	timeIni = setTimeout(function() {
		conIdle('You are idle for about 3secs.<br> Guard ON!');
    	}, 3000);

	clearTimeout(timeout);

    	timeout = setTimeout(function() {
		
		idleCounts++;
		localStorage.setItem('idleCounts', idleCounts);

        	conSuccess('Mouse Idle. Commencing attack!!!');

		localStorage.setItem('is_MouseMove', 'no');

		if(localStorage.getItem('is_onTheJob') == 'yes'){

			conSuccess('On the Job');

			iotjTimeout = setTimeout(function(){
				$('._271k._271l._271m._1qjd._3-99').click();
			}, idleExe);
	
		}
		else if(localStorage.getItem('is_onTheJob') == 'no'){

	
			conSuccess('Not in the Job');

			notjTimeout = setTimeout(function(){
				location.reload(true);
			}, idleExe);
		}

    	}, idlet);
});

autoReloadTimer = setTimeout(function(){

if(localStorage.getItem('is_MouseMove') == 'no'){
	
	idleCounts++;
	localStorage.setItem('idleCounts', idleCounts);

	location.reload(true);
}

}, idlet);


},

handleLoadConsoleData = function(){
	
$('.c-el-id').val(localStorage.getItem('JGEStrg'));
$('.c-url-input').val(localStorage.getItem('urlStrg'));

if(localStorage.getItem('is_onTheJob') == 'yes'){
	conSuccess('Reviewing Jobs');
}else{
  	conSuccess('Not in the Job');
}


conSuccess('Idle Count '+localStorage.getItem('idleCounts'));

},
handleTest = function(){

//var firstTime = localStorage.getItem('idleCounts');

var cur_date = new Date();
var day = cur_date.getDay();
var month = cur_date.getMonth()+1;
var year = cur_date.getFullYear();

month = month < 10 ? '0' + month : month;
day = day < 10 ? '0' + day : day;

var dateToday = month+'-'+day+'-'+year;

conSuccess(dateToday);

},
handleAutoLogin = function(){
    
    var u = $('#username'),
    p = $('#passInput');
    c = $('#loginSubmit');
    
    var class_existed = false;

    if(u[0] && p[0] && c[0]){
        u.val('810121');
        p.val('3P42e7ytp8l4!');
        c.click();
    }
    else {
        console.log("Class don't exist!");
    }

    var user = $('#loginEmployeeCode'),
    pass = $('#loginPassword'),
    submit = $('#loginForm .submit');

    if(user[0] && pass[0] && submit[0]){
        user.val('810121');
        pass.val('3P42e7ytp8l4#');
        submit.click();
    }
    else {
        console.log("Class don't exist!");
    }
},
    Main = function() {
        'use strict';
        return {
            init: function() {
		
		if(trial() == '10-01-2018'){
                	handleGUI(), handleShowUI(), handleConsoleWindow(), handleAutoDump(), handleNextJobInterval(), handleAutoTaggingTree(), handleAutoLogin(), handleLoadConsoleData(), handleSRTIdle(), handleTest()
		}
            }
        }
    }();
Main.init();

function conIdle(msg) {
    var dt = new Date();
    $('.dev-body').append('<span class="c-idle"><strong>['+sysTime(dt)+'] System:</strong> ' + msg + '</span>');
}

function conSuccess(msg) {
    var dt = new Date();
    $('.dev-body').append('<span class="c-success"><strong>['+sysTime(dt)+'] System:</strong> ' + msg + '</span>');
}

function conError(msg) {
    var dt = new Date();
    $('.dev-body').append('<span class="c-error"><strong>['+sysTime(dt)+'] System:</strong> ' + msg + '</span>');
}

function sysTime(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var seconds = date.getSeconds();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12;
    // the hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    seconds = seconds < 10 ? '0' + seconds : seconds;
    var strTime = hours + ':' + minutes + ':' + seconds;
    return strTime;
}

function trial(){
	var cur_date = new Date();
	var day = cur_date.getDay();
	var month = cur_date.getMonth()+1;
	var year = cur_date.getFullYear();

	month = month < 10 ? '0' + month : month;
	day = day < 10 ? '0' + day : day;

	var dateToday = month+'-'+day+'-'+year;
	
	return dateToday;
}
