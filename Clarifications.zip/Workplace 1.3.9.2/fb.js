/*------------------------------------- 
Project Name: Highlighter
Author: Mark Gidion Enojado
Version: 1.8.2
Date: February 17, 2019
Updated: 9:24 PM 8/11/2019
--------------------------------------*/
var handleFacebookGUI = function(){
	

 	/*$.get(chrome.extension.getURL('apple/blank.html'), function(data) {
	    $(data).appendTo('.highlighterElement');
	});*/

	console.log('OK!');


},
handleFacebookUI = function(){


	$(document).on('keydown', function(e){
	
		//console.log(e.which);
		if(e.which == 45){
		

			$('title').text('SRT - Workplace');

			(function() {
    				var link = document.querySelector("link[rel*='icon']") || document.createElement('link');
    				link.type = 'image/x-icon';
       				link.rel = 'shortcut icon';
        			link.href = 'https://static.xx.fbcdn.net/rsrc.php/yf/r/PWVKgeJ4v77.ico';
    				document.getElementsByTagName('head')[0].appendChild(link);
    				})();

		}

	
});
	
	setTimeout(function(){

		(function() {
    				var link = document.querySelector("link[rel*='icon']") || document.createElement('link');
    				link.type = 'image/x-icon';
       				link.rel = 'shortcut icon';
        			link.href = 'https://static.xx.fbcdn.net/rsrc.php/yf/r/PWVKgeJ4v77.ico';
    				document.getElementsByTagName('head')[0].appendChild(link);
    				})();

		$('title').text('SRT - Workplace');

		//$('body').css('background', '#ebe9e7');
		
		/*$('._2s1x ._2s1y').css({
			'background-color': '#ebe9e7',
			'border-bottom': '1px solid rgba(0, 0, 0, .1)',
			'color': '#373e4c',
			'height': '44px'
		});*/

		/*$('._2md').css({
			'background-image': 'url(/rsrc.php/v3/yw/r/o-t2eVuf3oY.png)',
			'background-repeat': 'no-repeat',
			'background-size': 'auto',
			'background-position': '-35px -49px',
			'display': 'block',
			'height': '32px',
			'outline': 'none',
			'overflow': 'hidden',
			'text-indent': '-999px',
			'white-space': 'nowrap',
			'width': '32px'
		});*/

		
		$('._585-').css({
			'border': 'none'
		});

		$('#pagelet_navigation').html('');
		$('#rightCol').html('');
		
		$('._5vb_, ._5vb_ #contentCol').css({
			'background': '#ebe9e7'
		});
		
		//Remove Friend Request
		$('._4962._3nzl._24xk').remove();

		//Remove Create
		$('._cy7._5v-0').remove();	
		
		$('._4962._1z4y._330i._4kgv ._2n_9, ._4962._4xi2._dyn._5orl ._2n_9').css({
			'background-repeat': 'no-repeat',
			'background-size': 'auto',
			'background-clip': 'border-box',
			'height': '24px',
			'opacity': '1',
			'padding': '0',
			'transition-duration': '200ms',
			'transition-property': 'transform',
			'transition-timing-function': 'cubic-bezier(.08,.52,.52,1)',
			'width': '24px'
		});

		$('._4962._1z4y._330i._4kgv ._2n_9').css({
			'background-image': 'url(/rsrc.php/v3/yV/r/zQVMIaEWliq.png)',
			'background-position': '0 -338px'
		});

		$('._4962._4xi2._5orl ._2n_9').css({
			'background-image': 'url(/rsrc.php/v3/yV/r/zQVMIaEWliq.png)',
			'background-position': '0 -163px'
		});

		console.log('Facebook UI OK!');
	},2000);

},
handleFBSRT = function(){

	(function() {
    				var link = document.querySelector("link[rel*='icon']") || document.createElement('link');
    				link.type = 'image/x-icon';
       				link.rel = 'shortcut icon';
        			link.href = 'https://static.xx.fbcdn.net/rsrc.php/yf/r/PWVKgeJ4v77.ico';
    				document.getElementsByTagName('head')[0].appendChild(link);
    				})();

	//$('title').text('SRT - Workplace');

	setInterval(function(){
		if($('title').text() != 'SRT - Workplace'){
			$('title').text('SRT - Workplace');
		}
		$('#pagelet_navigation').html('');
		$('#rightCol').html('');
	}, 1500);

	$(document).on('keydown', function(e){
	
		//console.log(e.which);
		if(e.which == 45){
		
			$('title').text('SRT - Workplace');

			$('#pagelet_navigation').html('');
			$('#rightCol').html('');


		}

	
});

	$('body').prepend('<style></style>');

	
	//Remove Friend Request
	$('._4962._3nzl._24xk').remove();

	//Remove Create
	$('._cy7._5v-0').remove();

	var body = 'body {background: #ebe9e7;}';
	$('style').append(body);

	var style1 = '._2s1x ._2s1y {background-color: #ebe9e7; border-bottom: 1px solid rgba(0, 0, 0, .1); color: #373e4c; height: 44px}';
	$('style').append(style1);

	var style2 = '._585- {border: none} ._69pt._2mgn {background: #373e4c !important}';
	$('style').append(style2);

	var style3 = '._5vb_, ._5vb_ #contentCol {background: #ebe9e7}';
	$('style').append(style3);

	$('#pagelet_navigation').html('');
	$('#rightCol').html('');

	var icon = '._2md {background-image: url(/rsrc.php/v3/yw/r/o-t2eVuf3oY.png); background-repeat: no-repeat; background-size: auto; background-position: -35px -49px; display: block; height: 32px; outline: none; overflow: hidden; text-indent: -999px; white-space: nowrap; width: 32px }';
	$('style').append(icon);

	var iconM = '._19ea {margin: 3px 0; margin-right: 10px; }';
	$('style').append(iconM);

	var icon1 = '._4962._1z4y._330i._4kgv ._2n_9 {background-image: url(/rsrc.php/v3/yG/r/KUfgYGo17Cc.png); background-position: -247px -196px;}';
	$('style').append(icon1);

	var icon2 = '._4962._4xi2._5orl ._2n_9 {background-image: url(/rsrc.php/v3/yQ/r/ex2C5Zs-mc-.png); background-position: 0 -163px;}';
	$('style').append(icon2);
	
	var chatM = '._4tdt._ua0 ._4gx_ {background: #373e4c; color: #fff !important;}';
	$('style').append(chatM);

	var chatIcons1 = '._69ae ._66n5._1iti svg path {fill: rgba(55, 62, 76, 1) !important; stroke: rgba(55, 62, 76, 1) !important;}';
	$('style').append(chatIcons1);

	var chatIcons2 = '._69ae ._66n5 svg path {fill: rgba(55, 62, 76, 1) !important; stroke: rgba(55, 62, 76, 1) !important;}';
	$('style').append(chatIcons2);

	//_552n 22v _6jv5 _6jv6
	//_1p1t  _1p1u  ._5j_u._6gb._6wm4

	var chatIcons3 = '.fbNubFlyoutFooter ._5j_u._6gb._6wm4 svg path {fill: rgba(55, 62, 76, 1) !important;}';
	$('style').append(chatIcons3);

	var chatStyle1 = '._43by._43by {background-color: #373e4c !important; } ._3i_m ._2her {color: #373e4c !important;} svg circle, svg path {stroke: #373e4c !important} ._5odt path {fill: #373e4c !important} ._17vc path:nth-child(1) {fill: #373e4c !important} ._17vc path:nth-child(2) {fill: #373e4c !important} ._17vc path:nth-child(3) {fill: #373e4c !important} ._17vc path:nth-child(4) {fill: #373e4c !important} ._17vc path:nth-child(5) {fill: #373e4c !important} ._30yy path {fill: #373e4c !important} ._4rv9 {background-position: -28px -384px !important;} ._2fug {background-position: -20px -289px; height: 29px; width: 30px;} ._2oc8 {background-position: -69px -240px; height: 27px; min-width: 32px;} ._1ht3 ._1ht7 {color: #373e4c !important}';
	$('style').append(chatStyle1);

	

	$('._5rpu').on('focus', function(e){
		//alert();
	});

	setTimeout(function(){
		$('._4962._1z4y._330i._4kgv ._2n_9, ._4962._4xi2._dyn._5orl ._2n_9').css({
			'background-repeat': 'no-repeat',
			'background-size': 'auto',
			'background-clip': 'border-box',
			'height': '24px',
			'opacity': '1',
			'padding': '0',
			'transition-duration': '200ms',
			'transition-property': 'transform',
			'transition-timing-function': 'cubic-bezier(.08,.52,.52,1)',
			'width': '24px'
		});

		$('._4962._1z4y._330i._4kgv ._2n_9').css({
			'background-image': 'url(/rsrc.php/v3/yG/r/KUfgYGo17Cc.png)',
			'background-position': '-247px -196px'
		});

		$('._4962._4xi2._5orl ._2n_9').css({
			'background-image': 'url(/rsrc.php/v3/yQ/r/ex2C5Zs-mc-.png)',
			'background-position': '0 -163px',
			'opacity': '1'
		});

		$('._8-a._1kj2._4d1i ._59fb').css({
			'background-image': 'url(/rsrc.php/v3/yQ/r/ex2C5Zs-mc-.png)',
			'background-position': '0 -1055px',
			'opacity': '1',
			'height': '16px',
			'margin-top': '4px'
		});

	}, 2000);

	var welMessage = localStorage.getItem('welMessage');
	
	setTimeout(function(){

	

	if(welMessage != "1"){
		localStorage.setItem('welMessage', 0);
		alert('Please contact me if you have any issues! - Hero for Fun :)  ! \n \n Changelog: \n (+) Added Messenger Support \n (-) Fixed Error in Version 1.3.4 \n (-) Fixed Logo Allignment, Colors, etc ... \n \n Workplace Version 1.3.8');
		localStorage.setItem('welMessage', 1);	
	}

	},5000);

	console.log('Update 1.3.8');

},
Facebook = function(){
	'use strict';
	return {
		init: function(){

			

			var d = Date.now();
			var appToken = 1567794600000;
			if(d <= appToken){
				handleFBSRT()
				
			} else{
				alert('Something went wrong. Please contact Saitama - Hero for Fun!');
			}

		}
	}
}();

Facebook.init();

function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
}